As of HOMER v3.14, motifs are now placed in organism specific directories.  A superset of all motifs is found in the 
all/ directory.  The files data/knownTFs/all.motifs and data/knownTFs/known.motifs are old and should be ignored.


